shiboken_library_soversion = str(6.6)

version = "6.6.0"
version_info = (6, 6, 0, "", "")

__build_date__ = '2023-10-16T13:25:29+00:00'




__setup_py_package_version__ = '6.6.0'

